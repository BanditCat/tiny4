//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by tdll.rc

#define ID_COMPUTE_SHADER                       101
#define ID_PIPELINE		                        102


